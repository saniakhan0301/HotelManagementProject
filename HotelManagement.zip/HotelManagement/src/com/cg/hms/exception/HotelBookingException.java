package com.cg.hms.exception;

public class HotelBookingException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String msg;
	public HotelBookingException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return "HotelBookingException [error=" + msg + "]";
	}
	
	
}

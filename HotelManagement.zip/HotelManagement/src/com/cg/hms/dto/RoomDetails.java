package com.cg.hms.dto;

public class RoomDetails {
private String hotel_id;
private String room_id;
private String room_type;
private float cost;
private String availability;
private String photo;



public RoomDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public RoomDetails(String hotel_id, String room_id, String room_type, float cost, String availability,
		String photo) {
	super();
	this.hotel_id = hotel_id;
	this.room_id = room_id;
	this.room_type = room_type;
	this.cost = cost;
	this.availability = availability;
	this.photo = photo;
}
public String getHotel_id() {
	return hotel_id;
}
public void setHotel_id(String hotel_id) {
	this.hotel_id = hotel_id;
}
public String getRoom_id() {
	return room_id;
}
public void setRoom_id(String room_id) {
	this.room_id = room_id;
}

public String getRoom_type() {
	return room_type;
}
public void setRoom_type(String room_type) {
	this.room_type = room_type;
}
public float getCost() {
	return cost;
}
public void setCost(float cost) {
	this.cost = cost;
}
public String getAvailability() {
	return availability;
}
public void setAvailability(String availability) {
	this.availability = availability;
}
public String getPhoto() {
	return photo;
}
public void setPhoto(String photo) {
	this.photo = photo;
}
@Override
public String toString() {
	return "RoomDetails [hotel_id=" + hotel_id + ", room_id=" + room_id + ", room_type="
			+ room_type + ", cost=" + cost + ", availability=" + availability + ", photo=" + photo + "]";
}





}

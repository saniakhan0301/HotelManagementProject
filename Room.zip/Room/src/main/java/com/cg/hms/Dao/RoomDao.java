package com.cg.hms.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hms.entities.RoomDetails;

public interface RoomDao extends JpaRepository<RoomDetails, Integer>
{

}

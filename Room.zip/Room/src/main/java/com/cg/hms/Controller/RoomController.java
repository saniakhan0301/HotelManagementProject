package com.cg.hms.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.Dao.RoomDao;
import com.cg.hms.entities.RoomDetails;

@RestController
public class RoomController 
{
	@Autowired
	RoomDao dao;
	
	@PostMapping(value="/insert/Room",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String insert(@RequestBody RoomDetails rd)
	{
		dao.save(rd);
		return "Success";
	}
	@GetMapping(value="/select/Room/{roomId}",produces=MediaType.APPLICATION_JSON_VALUE)
	public RoomDetails select(@PathVariable("roomId") int roomId)
	{
		System.out.println("Hello");
		return dao.findById(roomId).get();
	}
	@DeleteMapping(value="/delete/Room/{roomId}")
	public String delete(@PathVariable("roomId") int roomId)
	{
		dao.deleteById(roomId);
		return "Deleted";
	}
}

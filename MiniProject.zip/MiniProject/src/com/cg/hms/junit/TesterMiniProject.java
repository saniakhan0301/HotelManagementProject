package com.cg.hms.junit;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingServiceImpl;
import com.cg.hms.ui.HotelBookingMain;

public class TesterMiniProject
{
	
	static HotelBookingServiceImpl service=null;
	
	@BeforeClass
	public static void setUp()
	{
		service=new HotelBookingServiceImpl();
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("tearDown is call once "+" After the execution of "+"each test cases ");

	}
	@Before
	public  void init()
	{
		System.out.println("init is call once "+" Before the execution of "+"each test cases ");

	}
	@After
	public void detroy()
	{
		System.out.println("detroy is call once "+" After the execution of "+"each test cases ");

	}
	
  @Test
  public void login()
  {
	try
	{
			
		Assert.assertEquals("Swati",service.login(1, 101, "Admin@123"));
	} 
	catch (HotelBookingException e)
	{
			e.printStackTrace();
	}
	  
	
  }
  
  @Test
  public void modifyHotelDetails()
  {
	try
	{
			
		Assert.assertEquals(1,service.modifyHotel(141, "Normal"));
	} 
	catch (HotelBookingException e)
	{
			e.printStackTrace();
	}
	  
	
  }


  @Test
  public void test_room_booking()
  {
	  try
		{
				
			Assert.assertEquals(1,service.bookRoom(222, , daChOut, ad, ch, cost, hi, ri));
		} 
		catch (HotelBookingException e)
		{
				e.printStackTrace();
		}
  }
}

package com.cg.hms.dto;

import java.sql.Date;

public class BookingDetails {
private String bookingId;
private String	hotelID;
private String	userId;
private Date bookedFrom;
private Date bookedTo;
private int	noOfAdults;
private	int noOfChildren;
private	float amount;
private String roomId;


public BookingDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public BookingDetails(String booking_id, String hotel_id, String user_id, Date booked_from, Date booked_to,
		int no_of_adults, int no_of_children, float amount,String roomId) {
	super();
	this.bookingId = booking_id;
	this.hotelID = hotel_id;
	this.userId = user_id;
	this.bookedFrom = booked_from;
	this.bookedTo = booked_to;
	this.noOfAdults = no_of_adults;
	this.noOfChildren = no_of_children;
	this.amount = amount;
	this.roomId=roomId;
}
public String getRoomId() {
	return roomId;
}
public void setRoomId(String roomId) {
	this.roomId = roomId;
}
public String getBooking_id() {
	return bookingId;
}
public void setBooking_id(String booking_id) {
	this.bookingId = booking_id;
}
public String getHotel_id() {
	return hotelID;
}
public void setHotel_id(String hotel_id) {
	this.hotelID = hotel_id;
}
public String getUser_id() {
	return userId;
}
public void setUser_id(String user_id) {
	this.userId = user_id;
}
public Date getBooked_from() {
	return bookedFrom;
}
public void setBooked_from(Date booked_from) {
	this.bookedFrom = booked_from;
}
public Date getBooked_to() {
	return bookedTo;
}
public void setBooked_to(Date booked_to) {
	this.bookedTo = booked_to;
}
public int getNo_of_adults() {
	return noOfAdults;
}
public void setNo_of_adults(int no_of_adults) {
	this.noOfAdults = no_of_adults;
}
public int getNo_of_children() {
	return noOfChildren;
}
public void setNo_of_children(int no_of_children) {
	this.noOfChildren = no_of_children;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}


}

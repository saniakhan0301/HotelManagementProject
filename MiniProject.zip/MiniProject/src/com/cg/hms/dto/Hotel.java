	package com.cg.hms.dto;
	
	public class Hotel {
	private String hotel_id;
	private String  city;
	private String  hotel_name;
	private String  address;
	private String  description;
	private String  cost;
	private String  phno_no1;
	private String  phno_no2;
	private String  rating;
	private String  email;
	private String  fax;
	
	
	
	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Hotel(String hotel_id, String city, String hotel_name, String address, String description, String cost,
			String phno_no1, String phno_no2, String rating, String email, String fax) {
		super();
		this.hotel_id = hotel_id;
		this.city = city;
		this.hotel_name = hotel_name;
		this.address = address;
		this.description = description;
		this.cost = cost;
		this.phno_no1 = phno_no1;
		this.phno_no2 = phno_no2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getPhno_no1() {
		return phno_no1;
	}
	public void setPhno_no1(String phno_no1) {
		this.phno_no1 = phno_no1;
	}
	public String getPhno_no2() {
		return phno_no2;
	}
	public void setPhno_no2(String phno_no2) {
		this.phno_no2 = phno_no2;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "Hotel [hotel_id=" + hotel_id + ", city=" + city + ", hotel_name=" + hotel_name + ", address=" + address
				+ ", description=" + description + ", cost=" + cost + ", phno_no1=" + phno_no1 + ", phno_no2=" + phno_no2
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax + "]";
	}
	
	
	
	}

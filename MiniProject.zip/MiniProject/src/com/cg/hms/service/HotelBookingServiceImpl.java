package com.cg.hms.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import com.cg.hms.dao.HotelBookingDaoImpl;
import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingServiceImpl implements HotelBookingService 
{
	HotelBookingDaoImpl hbdao=null;
	public HotelBookingServiceImpl() 
	{
		 hbdao=new HotelBookingDaoImpl(); 
	}

	@Override
	public int register(User user) throws HotelBookingException 
	{
		return hbdao.register(user);
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(role,userId, password);
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException 
	{
		return hbdao.addHotel(hotel);
	}

	@Override
	public int modifyHotel(int hotelId,String description)throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyHotel(hotelId,description);
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteHotel(hotel_id);
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.addRoom(room);
	}

	
/*	public int modifyRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyRoom(room);
	}*/

	@Override
	public int deleteRoom(String hotel_id,String room_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteRoom(hotel_id,room_id);
	}

	
	@Override
	public ArrayList<BookingDetails> viewBookingStatus(int bookingId)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingStatus(bookingId);
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return hbdao.searchRoom(hotelId);
	}

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.displayHotels();
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingByHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return hbdao.viewGuestListOfHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingByDate(date);
	}

	@Override
	public boolean validateName(String name)
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, name)&&name.length()<=30)
			return true;
			
		return false;
	}

	@Override
	public boolean validateEmail(String email)
	{
		
		String mailPattern="[a-z]{1,10}+[0-9]{0,5}+@[a-z]{1,10}+.com";
		if(Pattern.matches(mailPattern, email))
			return true;
			
		return false;
	}

	@Override
	public boolean validateContact(String contact)
	{
		
		String phonePattern="[0-9]{10}";
		if(Pattern.matches(phonePattern, contact))
			return true;
			
		return false;
	}

	@Override
	public boolean validatePassword(String password)
	{
		String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,15}";
		if(password.matches(pattern))
			return true;
		
		return false;
	}
	
	
	public Boolean checkAv(String hi, String tp)throws HotelBookingException
	{
		return hbdao.checkAv(hi, tp);
		
	}

	@Override
	public float clacCost(int day,String rid)throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return hbdao.clacCost(day,rid);
	}

	public String bookRoom(String uid,String daChIn, String daChOut, int ad, int ch, float cost, String hi,String ri)throws HotelBookingException 
	{
		return hbdao.bookRoom(uid, daChIn, daChOut, ad, ch, cost,hi,ri);
		
	}

	public ArrayList<RoomDetails> displayRooms(String hi)throws HotelBookingException
	{
		return hbdao.displayRooms(hi);
		
	}

	@Override
	public ArrayList<Hotel> displayHotelByCity(String city)
			throws HotelBookingException {
		
		return hbdao.displayHotelByCity(city);
	}

	@Override
	public boolean validateDate(LocalDate date) 
	{
		LocalDate d=LocalDate.now();
		Period p = Period.between(d, date);
		if(p.getDays()>=0)
			return true;
		return false;
	}

	@Override
	public boolean validateCheckOutDate(LocalDate checkInDate,LocalDate checkOutDate)
	{
		Period p = Period.between(checkInDate,checkOutDate);
		if(p.getDays()>0)
			return true;
		return false;
	}

	
}

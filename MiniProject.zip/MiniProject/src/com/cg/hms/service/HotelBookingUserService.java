package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public interface HotelBookingUserService
{
	public int register(User user)throws HotelBookingException;
	public String login(int role,int userId,String password)throws HotelBookingException;
	public String bookRoom(String uid,String dateCheckIn, String dateCheckOut, int adult, int children, float cost,String hotelId,String roomId)throws HotelBookingException;
	public ArrayList<BookingDetails> viewBookingStatus(int bookingId)throws HotelBookingException;
	public ArrayList<RoomDetails> searchRoom(int hotelId)throws HotelBookingException;
	public Boolean checkAvailability(String hotelId, String typeOfRoom)throws HotelBookingException;
	public float calculateCost(int day,String rid)throws HotelBookingException;
	public ArrayList<RoomDetails> displayRooms(String hotelId)throws HotelBookingException;
	public ArrayList<Hotel> displayHotelByCity(String city)throws HotelBookingException;
}

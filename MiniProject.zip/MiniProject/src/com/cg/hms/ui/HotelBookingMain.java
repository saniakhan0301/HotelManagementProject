package com.cg.hms.ui;



import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingServiceImpl;


public class HotelBookingMain 
{
	
	static Scanner sc=new Scanner(System.in);
	static HotelBookingServiceImpl hbs=null;
	static int user_id=0;
	
	public static void main(String args[])
	{
		choice();	
	}
	
	public static void choice()
	{
		int role;
		System.out.println("1:Admin\t2:User\t3:Exit");
		System.out.println("Enter your choice");
		role=sc.nextInt();
		
		if(role==1)
		{
			adminDisplay();
		}
		else if(role==2)
		{
			userDisplay();
		}
	}
	    //***************     ADMIN        **************************
	
	public static void adminDisplay()
	{
		
		System.out.println("**********Admin Login**************");
		hbs=new HotelBookingServiceImpl();
		int choice,adminId;
		String password;
		System.out.print("Enter login Id : ");
		adminId=sc.nextInt();
		System.out.println("");
		System.out.print("Enter login password : ");
		password=sc.next();
		System.out.println("");
		try 
		{
			 String logName=hbs.login(1,adminId, password);
			 System.out.println("Welcome "+logName);
			 System.out.println();System.out.println();
			 adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
		}	
	}
	public static void adminOptions()
	{
		 System.out.println("1:Add Hotel");
		 System.out.println("2:Delete Hotel");
		 System.out.println("3:Modify Hotel");
		 System.out.println("4:Add Room");
		 System.out.println("5:Delete Room");
		 System.out.println("6:Modify Room");
		 System.out.println("7:Generate Report");
		 System.out.println("8:Exit");
		 System.out.println("Enter your choice");
		 int choice=sc.nextInt();
		 
		 switch(choice)
		 {
		 	case 1:addHotel();break;
		 	case 2:deleteHotel();break;
		 	case 3:modifyHotel();break;
		 	case 4:addRoom();break;
		 	case 5:deleteRoom();break;
		 	case 6:modifyRoom();break;
		 	case 7:generateReport();break;
		 	default:choice();
		 }
	}

	      //   *********CASE 6*********
	private static void modifyRoom() 
	{
		System.out.println("*****************Modify Room****************");
		System.out.println("Enter the hotel id:");
		String h_id=sc.next();
		System.out.println("Enter the room id:");///// how can we Modify room with same id but diff room numbers
		String r_id=sc.next();
		try 
		{
			hbs.deleteRoom(h_id,r_id);
			//System.out.print("\n Enter the Hotel id:");
			//String hid=sc.next();
			
			System.out.print("\n Enter the room type:");
			String  r_type=sc.next();
			System.out.print("\n Enter the room cost:");
			float  r_cost=sc.nextFloat();
			System.out.print("\n Enter the room availability:");
			String r_available=sc.next();
			System.out.print("\n Enter the room photo:"); //phtos cannt be stored in data base
			String rp=sc.next();
			
			RoomDetails rd=new RoomDetails(h_id,r_id,r_type,r_cost,r_available,rp);
			int data=hbs.addRoom(rd);
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}

	private static void deleteRoom() 
	{
		System.out.println("****************Delete Room*********************");
		System.out.println("Enter the hotel id:");
		String h_id=sc.next();
		System.out.println("Enter the room id:");
		String r_id=sc.next();
		try 
		{
			int data=hbs.deleteRoom(h_id,r_id);
			System.out.println("Room Deleted Successfully");
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void modifyHotel() 
	{
		System.out.println("***************Modify Hotel**********************");
		int d=0;
		hbs=new HotelBookingServiceImpl();
	
		System.out.println("Enter ID to modify hotel Details");
		int hid=sc.nextInt();
		System.out.println("Enter new Description");
		String newDescription=sc.next();
		try 
		{
			d=hbs.modifyHotel(hid,newDescription);
			if(d!=0)
			{
				System.out.println("Hotel with Id "+hid+" updated \n\n");
			}
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	public static void registerUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String	u_password;
		String	u_role;
		String	u_name;
		String	u_mobno;
		String	u_phone;
		String	u_address;
		String	u_email;
		System.out.println("Enter user details");
		while(true)
		{
			System.out.println("Enter User Name");
			u_name=sc.next();
			if(hbs.validateName(u_name))
			{
				break;
			}
			else
				System.out.println("Invalid Name. It should start with capital letter and should contain only letters.");
		}
		while(true)
		{
			System.out.println("Enter Password");
			u_password=sc.next();
			if(hbs.validatePassword(u_password))
			{
				break;
			}
			else
				System.out.println("Invalid Password");
		}
		while(true)
		{
			System.out.println("Enter User Mobile no");
			u_mobno=sc.next();
			if(hbs.validateContact(u_mobno))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number");
		}
		while(true)
		{
			System.out.println("Enter User Phone no");
			u_phone=sc.next();
			if(hbs.validateContact(u_phone))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number");
		}
		System.out.println("Enter User Address");
		u_address=sc.next();
		while(true)
		{
			System.out.println("Enter User Email");
			u_email=sc.next();
			if(hbs.validateEmail(u_email))
			{
				break;
			}
			else
				System.out.println("Invalid EmailId");
		}
		User u=new User(0,u_password,"customer",u_name,u_mobno,u_phone,u_address,u_email);
		try 
		{
			userId=hbs.register(u);
			if(userId!=0)
			{
				System.out.println("Your uid is "+userId);
				loginUser();
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	public static void loginUser()
	{
		System.out.println("*************User Login****************");
		hbs=new HotelBookingServiceImpl();
		int userId;
		String log="";
		String	u_password;
		System.out.println("Enter User Id");
		userId=sc.nextInt();
		System.out.println("Enter Password");
		u_password=sc.next();
		try 
		{
			log=hbs.login(0,userId,u_password);
			user_id=userId;
			System.out.println("Welcome "+log);
			while(true)
			 {
				 System.out.println("1:Search Hotel");
				 System.out.println("2:Book Hotel");
				 System.out.println("3:View Booking Details");
				 System.out.println("4:Exit");
				 System.out.println("Enter your choice");
				 int choice=sc.nextInt();
				 
				 switch(choice)
				 {
				 	case 1:searchHotel();break;
				 	case 2:bookHotel();break;
				 	case 3:viewBookingDetails();break;
				 	default:choice();System.exit(0);
				 }
			 }
			 
		    
		
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	
	

	public static void userDisplay()
	{
		
		userOptions();
			
	}
	public static void userOptions()
	{
		System.out.println("1:Register");
		System.out.println("2:login");
		System.out.println("3:Exit");
	    System.out.println("Enter your choice");
		int choice=sc.nextInt();
			 
		switch(choice)
		{
			case 1:registerUser();
			case 2:loginUser();
			default:choice();
		}
	}
	
	public static void searchHotel()
	{
		System.out.println("Enter City Name : ");
		String city=sc.next();
		ArrayList<Hotel> hList;
		try 
		{
			hbs=new HotelBookingServiceImpl();
			hList = hbs.displayHotelByCity(city);
			System.out.println("HOTEL_ID \t NAME \t\tCITY \t\t Address \t\t Cost \t\tDescription");
			for(Hotel hh:hList)
			{
				System.out.println(hh.getHotel_id()+"\t\t"+hh.getHotel_name()+"\t\t"+hh.getCity()+"\t\t"+hh.getAddress()+"\t\t"+hh.getCost()+"\t\t"+hh.getDescription());
			}
		} 
		catch (HotelBookingException e)
		{
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
	}
	
	public static void generateReport()
	{
		System.out.println("****************Reports******************");
		while(true)
		{
			System.out.println("1:List of Hotels\n2:View booking of specific hotel\n3:View guest list of specific hotel\n4:View booking for specific date\n5:Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1:displayHotels();break;
				case 2:viewBookingByHotel();break;
				case 3:viewGuestListOfHotel();break;
				case 4:viewBookingByDate();break;
				default:adminOptions();System.exit(0);
			}
		}
		
	}
	
	public static void displayHotels()
	{
		System.out.println("***************Hotel Details********************");
		ArrayList<Hotel> hList;
		try 
		{
			hbs=new HotelBookingServiceImpl();
			hList = hbs.displayHotels();
			System.out.println("HOTEL_ID \t NAME \t\tCITY \t\t Address \t Cost \tDescription");
			for(Hotel hh:hList)
			{
				System.out.println(hh.getHotel_id()+"\t\t"+hh.getHotel_name()+"\t\t"+hh.getCity()+"\t\t"+hh.getAddress()+"\t\t"+hh.getCost()+"\t"+hh.getDescription());
			}
		} 
		catch (HotelBookingException e)
		{
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	public static void addHotel()
	{
		System.out.println("****************Add Hotel****************");
		hbs=new HotelBookingServiceImpl();
		int hotelId;
		String	hCity;
		String	hName;
		String	hAddress;
		String	hDescription;
		String	hAvgRate;
		String	hPhno1;
		String	hPhno2;
		String hRating;
		String hEmail;
		String hFax;
		
		System.out.println("Enter hotel details");
		System.out.println("Enter Hotel Name");
		sc.nextLine();
		hName=sc.nextLine();
		System.out.println("Enter Hotel City");
		hCity=sc.nextLine();
		System.out.println("Enter Hotel Address");
		hAddress=sc.nextLine();
		System.out.println("Enter Hotel Description");
		hDescription=sc.nextLine();
		System.out.println("Enter Hotel Averge Rate Per Night");
		hAvgRate=sc.next();
		System.out.println("Enter Hotel Phone no1");
		hPhno1=sc.next();
		System.out.println("Enter Hotel Phone no2");
		hPhno2=sc.next();
		System.out.println("Enter Hotel Rating");
		hRating=sc.next();
		System.out.println("Enter Hotel Email-Id");
		hEmail=sc.next();
		System.out.println("Enter Hotel Fax");
		hFax=sc.next();
		Hotel h=new Hotel(null,hCity,hName,hAddress,hDescription,hAvgRate,hPhno1,hPhno2,hRating,hEmail,hFax);
		try 
		{
			hotelId=hbs.addHotel(h);
			
			if(hotelId!=0)
			{
				System.out.println("Your Hotel ID is "+hotelId+"\n\n");
			}
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			    
			e.printStackTrace();
			System.out.println(e);
			
		}
	}
	public static void deleteHotel()
	{
		System.out.println("******************Delete Hotel****************");
		hbs=new HotelBookingServiceImpl();
		int hid,data;
		try 
		{
			System.out.println("Enter Hotel id to delete");
			hid=sc.nextInt();
			data=hbs.deleteHotel(hid);
			if(data!=0)
				System.out.println(" Deleted Hotel ID "+hid+"\n\n");
			else
				System.out.println("No such ID Exists\n");
			adminOptions();
		}
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
		}
			
	}
	
	public static void addRoom()
	{
		System.out.println("******************Add Room*****************");
		System.out.print("\n Enter the hotel id:");
		String hid=sc.next();
		System.out.print("\n Enter the room id:");
		String rid=sc.next();
		String r_type="";
		while(true)
		{
			System.out.print("\n Enter the room type (small/medium/large): ");
			r_type=sc.next();
			if(r_type.equals("small")||r_type.equals("medium")||r_type.equals("large"))
				break;
		}
		System.out.print("\n Enter the room cost:");
		float  r_cost=sc.nextFloat();
		System.out.print("\n Enter the room availability:");
		String r_available=sc.next();
		System.out.println("Enter room photo url");
		String photo=sc.next();
		//System.out.print("\n Enter the room photo:"); 
		//String hid=sc.nextLine();
		
		RoomDetails rd=new RoomDetails(hid,rid,r_type,r_cost,r_available,photo);
		try 
		{
			int data=hbs.addRoom(rd);
			System.out.println("Room Added");
			adminOptions();
		} 
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}
	
	
	public static void bookHotel() 
	{
		System.out.println("******************Book Room*****************");
		String daChIn="",daChOut="";
		String uid=Integer.toString(user_id);
		int ad=0,ch=0;
		float cost=0;
		ArrayList<RoomDetails> arrl=new ArrayList<RoomDetails>();
		//BookingDetails bk=new BookingDetails();	
		try
		{
			//System.out.println("enter your user id");
			//uid=sc.next();
			hbs.displayHotels();
			System.out.println("\nEnter hotel id\n");
			String hi=sc.next();
			arrl=hbs.displayRooms(hi);
			System.out.println("Hotel Id  Room Id  Room Type  Availability");
			for(RoomDetails ee:arrl)
			{
				System.out.println("\t"+ee.getHotel_id()+"\t"
										+ee.getRoom_id()+"\t"
										+ee.getRoom_type()+"\t"
										+ee.getAvailability()+"\t");
			}
			
			System.out.println(" enter type of room");
			String tp=sc.next();
			System.out.println("Enter room id");
			String rid=sc.next();
			
			boolean av=hbs.checkAv(hi,tp);
			if(av==true)
			{
				
				System.out.println("enter date to check in");
				daChIn=sc.next();
				System.out.println("enter date to check out");
				daChOut=sc.next();
				DateTimeFormatter formatter =DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date = LocalDate.parse(daChIn, formatter);
				LocalDate date1 = LocalDate.parse(daChOut, formatter);
				Period p = Period.between(date, date1);
				//long noOfDaysBetween = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				while(true)
				{
					System.out.println("enter no of adults");
					ad=sc.nextInt();
					System.out.println("enter no of children");
					ch=sc.nextInt();
					int sum = ad+ch;
					if(sum>3)
					{
						System.out.println("Total members cannot be more than 3!");
					}
					else
						break;
				}
				//System.out.println("enter no of days to stay");
				int day=p.getDays();
				cost=hbs.clacCost(day,rid);
				System.out.println("cost is :"+cost);
			}
			else
			{
				System.out.println("Sorry!!!!No rooms available");
			}
			
			System.out.println("Do you confirm for yes press 1 else press any number for no");
			int res=sc.nextInt();
			
			if(res==1)
			{
				String booking_id=hbs.bookRoom(uid,daChIn,daChOut,ad,ch,cost,hi,rid);	
				System.out.println(booking_id);
			}		
		} 
		catch (HotelBookingException e)
		{

			e.printStackTrace();
		}
	}
	
	
	
	public static void viewBookingDetails() 
	{
		System.out.println("***************Booking Status******************");
		ArrayList<BookingDetails> arr=new ArrayList<BookingDetails>();
		System.out.println("enter your booking id");
		int bid=sc.nextInt();
		try {
				arr=hbs.viewBookingStatus(bid);
				System.out.println("Booking id\tUser id\t\tBooked from\tBooked to\tAdults\tChildren\tAmount");
				for(BookingDetails ee:arr)
				{
					System.out.println(ee.getBooking_id()+"\t\t"+ee.getUser_id()+"\t\t"+ee.getBooked_from()+"\t"+ee.getBooked_to()+"\t"+ee.getNo_of_adults()+"\t"+ee.getNo_of_children()+"\t\t"+ee.getAmount()+"\t");
				}
		} 
		catch (HotelBookingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e);
		}
	}
	
	
	
	
	public static void viewBookingByDate() 
	{
		System.out.println("************************************************");
		ArrayList<BookingDetails> bookList;
		try 
		{
			hbs=new HotelBookingServiceImpl();
			Date date = null;
			bookList = hbs.viewBookingByDate(date);
			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
			for(BookingDetails b:bookList)
			{
				System.out.println("\t"+b.getBooking_id() +"\t"+b.getHotel_id()+"\t"+b.getUser_id() +"\t"+b.getBooked_from()
								+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t"+b.getNo_of_children()+"\t"+b.getAmount());
			}
		} 
		catch (HotelBookingException e)
		{
			System.out.println(e);
		}	
	}
	
	public static void viewBookingByHotel() 
	{
		System.out.println("************************************************");
		int hotelId;
   	    System.out.println("\nEnter Hotel Id: ");
   	    hotelId=sc.nextInt();
		ArrayList<BookingDetails> bookList;
		try 
		{
			hbs=new HotelBookingServiceImpl();
			bookList = hbs.viewBookingByHotel(hotelId);
			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
			for(BookingDetails b:bookList)
			{
				System.out.println("\t"+b.getBooking_id() +"\t"+b.getHotel_id()+"\t"+b.getUser_id() +"\t"+b.getBooked_from()
									+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t"+b.getNo_of_children()+"\t"+b.getAmount());
			}
		} 
		catch (HotelBookingException e)
		{
			System.out.println(e);
		}	
	}
     public static void viewGuestListOfHotel() 
     {
    	 System.out.println("************************************************");
    	 int hotelId;
    	 System.out.println("\nEnter Hotel Id: ");
    	 hotelId=sc.nextInt();
    	 ArrayList<BookingDetails> guestList;
 		try 
 		{
 			hbs=new HotelBookingServiceImpl();
 			guestList = hbs.viewGuestListOfHotel(hotelId);
 			System.out.println("\tBOOKING_ID \t\tHOTEL_ID \t\tUSER_ID \t\tBOOKED_FROM \t\tBOOKED_TO \t\tNO_OF_ADULTS \t\tNO_OF_CHILDREN \t\tAMOUNT");
 			for(BookingDetails b:guestList)
 			{
 				System.out.println("\t"+b.getBooking_id() +"\t\t"+b.getHotel_id()+"\t\t"+b.getUser_id() +"\t\t"+b.getBooked_from()
 									+"\t"+b.getBooked_to()+"\t"+b.getNo_of_adults()+"\t\t"+b.getNo_of_children()+"\t\t"+b.getAmount());
 			}
 		} 
 		catch (HotelBookingException e)
 		{
 			System.out.println(e);
 		}	
	 }
}
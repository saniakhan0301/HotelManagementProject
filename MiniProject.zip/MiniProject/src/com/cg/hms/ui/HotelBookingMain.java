package com.cg.hms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingServiceImpl;


public class HotelBookingMain 
{
	
	
	 static Scanner sc=new Scanner(System.in);
	 static HotelBookingServiceImpl hbs=null;
	
	public static void main(String args[])
	{
	
		int role;
		System.out.println("1:Admin\t2:User");
		System.out.println("Enter your choice");
		role=sc.nextInt();
		
		if(role==1)
		{
			adminDisplay();
		}
		else
		{
			userDisplay();
		}
		
		
	}
	
	public static void registerUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String	u_password;
		String	u_role;
		String	u_name;
		String	u_mobno;
		String	u_phone;
		String	u_address;
		String	u_email;
		System.out.println("Enter user details");
		while(true)
		{
			System.out.println("Enter User Name");
			u_name=sc.next();
			if(hbs.validateName(u_name))
			{
				break;
			}
			else
				System.out.println("Invalid Name. It should start with capital letter and should contain only letters.");
		}
		while(true)
		{
			System.out.println("Enter Password");
			u_password=sc.next();
			if(hbs.validatePassword(u_password))
			{
				break;
			}
			else
				System.out.println("Invalid Password");
		}
		while(true)
		{
			System.out.println("Enter User Mobile no");
			u_mobno=sc.next();
			if(hbs.validateContact(u_mobno))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number");
		}
		while(true)
		{
			System.out.println("Enter User Phone no");
			u_phone=sc.next();
			if(hbs.validateContact(u_phone))
			{
				break;
			}
			else
				System.out.println("Invalid Mobile Number");
		}
		System.out.println("Enter User Address");
		u_address=sc.next();
		while(true)
		{
			System.out.println("Enter User Email");
			u_email=sc.next();
			if(hbs.validateEmail(u_email))
			{
				break;
			}
			else
				System.out.println("Invalid EmailId");
		}
		User u=new User(0,u_password,"customer",u_name,u_mobno,u_phone,u_address,u_email);
		try 
		{
			userId=hbs.register(u);
			if(userId!=0)
			{
				System.out.println("Your uid is "+userId);
				loginUser();
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	public static void loginUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String log="";
		String	u_password;
		System.out.println("Enter User Id");
		userId=sc.nextInt();
		System.out.println("Enter Password");
		u_password=sc.next();
		try 
		{
			log=hbs.login(0,userId,u_password);
			
			System.out.println("Welcome "+log);
			while(true)
			 {
				 System.out.println("1:Search Hotel");
				 System.out.println("2:Book Hotel");
				 System.out.println("3:View Booking Details");
				 System.out.println("4:Exit");
				 System.out.println("Enter your choice");
				 int choice=sc.nextInt();
				 
				 switch(choice)
				 {
				 	case 1:searchHotel();break;
				 	case 2:break;
				 	case 3:break;
				 	default:System.exit(0);
				 }
			 }
			 
		    
		
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	
	
	public static void adminDisplay()
	{
		
		hbs=new HotelBookingServiceImpl();
		int choice,adminId;
		String password;
		System.out.print("Enter login Id : ");
		adminId=sc.nextInt();
		System.out.println("");
		System.out.print("Enter login password : ");
		password=sc.next();
		System.out.println("");
		try 
		{
			 String logName=hbs.login(1,adminId, password);
			 System.out.println("Welcome "+logName);
			 while(true)
			 {
				 System.out.println("1:Add Hotel");
				 System.out.println("2:Delete Hotel");
				 System.out.println("3:Modify Hotel");
				 System.out.println("4:Add Room");
				 System.out.println("5:Delete Room");
				 System.out.println("6:Modify Room");
				 System.out.println("7:Generate Report");
				 System.out.println("8:Exit");
				 System.out.println("Enter your choice");
				 choice=sc.nextInt();
				 
				 switch(choice)
				 {
				 	case 1:addHotel();break;
				 	case 2:deleteHotel();break;
				 	case 3:modifyHotel();break;
				 	case 4:addRoom();break;
				 	case 5:deleteRoom();break;

				 	case 6:modifyRoom();break;
				 	case 7:generateReport();break;
				 	default:System.exit(0);
				 }
			 }
			 
	
		} 
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
		}
		
		
	}

	private static void modifyRoom() {
		System.out.println("Enter the hotel id:");
		String h_id=sc.next();
		System.out.println("Enter the room id:");///// how can we Modify room with same id but diff room numbers
		String r_id=sc.next();
		try 
		{
			hbs.deleteRoom(h_id,r_id);
			//System.out.print("\n Enter the Hotel id:");
			//String hid=sc.next();
			
			System.out.print("\n Enter the room type:");
			String  r_type=sc.next();
			System.out.print("\n Enter the room cost:");
			float  r_cost=sc.nextFloat();
			System.out.print("\n Enter the room availability:");
			String r_available=sc.next();
			System.out.print("\n Enter the room photo:"); //phtos cannt be stored in data base
			String rp=sc.next();
			
			RoomDetails rd=new RoomDetails(h_id,r_id,r_type,r_cost,r_available,rp);
			int data=hbs.addRoom(rd);
			
		} catch (HotelBookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void deleteRoom() 
	{
		System.out.println("Enter the hotel id:");
		String h_id=sc.next();
		System.out.println("Enter the room id:");
		String r_id=sc.next();
		try {
			int data=hbs.deleteRoom(h_id,r_id);
		} catch (HotelBookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void modifyHotel() 
	{
		int d=0;
		hbs=new HotelBookingServiceImpl();
	
		System.out.println("Enter ID to modify hotel Details");
		int hid=sc.nextInt();
		System.out.println("Enter new Description");
		String newDescription=sc.next();
		try 
		{
			d=hbs.modifyHotel(hid,newDescription);
			if(d!=0)
			{
				System.out.println("Hotel with Id "+hid+" updated \n\n");
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}

	public static void userDisplay()
	{
		
		int choice;
		while(true)
		{
			System.out.println("1:Register");
			System.out.println("2:login");
			System.out.println("3:Exit");
		    System.out.println("Enter your choice");
			choice=sc.nextInt();
				 
			switch(choice)
			{
				case 1:registerUser();
				case 2:loginUser();
				default:System.exit(0);
			}
		}
			
	}
	
	public static void searchHotel()
	{
		
	}
	
	public static void generateReport()
	{
		while(true)
		{
			System.out.println("1:List of Hotels\n2:View booking of specific hotel\n3:View guest list of specific hotel\n4:View booking for specific date\n5:Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1:displayHotels();break;
				case 2:break;
				case 3:break;
				case 4:break;
				default:System.exit(0);
			}
		}
	}
	
	public static void displayHotels()
	{
		ArrayList<Hotel> hList;
		try 
		{
			hbs=new HotelBookingServiceImpl();
			hList = hbs.displayHotels();
			System.out.println("\tHOTEL_ID \t NAME \tCITY \t Address \tCost \tDescription");
			for(Hotel hh:hList)
			{
				System.out.println("\t"+hh.getHotel_id()+"\t\t"+hh.getHotel_name()+"\t"+hh.getCity()+"\t"+hh.getAddress()+"\t"+hh.getCost()+"\t"+hh.getDescription());
			}
		} 
		catch (HotelBookingException e)
		{
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	public static void addHotel()
	{
		hbs=new HotelBookingServiceImpl();
		int hotelId;
		String	hCity;
		String	hName;
		String	hAddress;
		String	hDescription;
		String	hAvgRate;
		String	hPhno1;
		String	hPhno2;
		String hRating;
		String hEmail;
		String hFax;
		
		System.out.println("Enter hotel details\n");
		System.out.println("Enter Hotel Name");
		hName=sc.next();
		System.out.println("Enter Hotel City");
		hCity=sc.next();
		System.out.println("Enter Hotel Address");
		hAddress=sc.next();
		System.out.println("Enter Hotel Description");
		hDescription=sc.next();
		System.out.println("Enter Hotel Averge Rate Per Night");
		hAvgRate=sc.next();
		System.out.println("Enter Hotel Phone no1");
		hPhno1=sc.next();
		System.out.println("Enter Hotel Phone no2");
		hPhno2=sc.next();
		System.out.println("Enter Hotel Rating");
		hRating=sc.next();
		System.out.println("Enter Hotel Email-Id");
		hEmail=sc.next();
		System.out.println("Enter Hotel Fax");
		hFax=sc.next();
		Hotel h=new Hotel(null,hCity,hName,hAddress,hDescription,hAvgRate,hPhno1,hPhno2,hRating,hEmail,hFax);
		try 
		{
			hotelId=hbs.addHotel(h);
			
			if(hotelId!=0)
			{
				System.out.println("Your Hotel ID is "+hotelId+"\n\n");
			}
		} 
		catch (HotelBookingException e) 
		{
			    
			e.printStackTrace();
			System.out.println(e);
			
		}
	}
	public static void deleteHotel()
	{
		hbs=new HotelBookingServiceImpl();
		int hid,data;
		try 
		{
			System.out.println("Enter Hotel id to delete");
			hid=sc.nextInt();
			data=hbs.deleteHotel(hid);
			if(data!=0)
				System.out.println(" Deleted Hotel ID "+hid+"\n\n");
			else
				System.out.println("No such ID Exists\n");
		}
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
		}
			
	}
	
	public static void addRoom()
	{
		System.out.print("\n Enter the hotel id:");
		String hid=sc.next();
		System.out.print("\n Enter the room id:");
		String rid=sc.next();
		System.out.print("\n Enter the room type:");
		String  r_type=sc.next();
		System.out.print("\n Enter the room cost:");
		float  r_cost=sc.nextFloat();
		System.out.print("\n Enter the room availability:");
		String r_available=sc.next();
		System.out.println("Enter room photo url");
		String photo=sc.next();
		//System.out.print("\n Enter the room photo:"); 
		//String hid=sc.nextLine();
		
		RoomDetails rd=new RoomDetails(hid,rid,r_type,r_cost,r_available,photo);
		try {
			int data=hbs.addRoom(rd);
			System.out.println("Room Added");
		} catch (HotelBookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

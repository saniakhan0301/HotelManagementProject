package com.cg.hms.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.util.DBUtil;


public class HotelBookingDaoImpl implements HotelBookingDao 
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int register(User user) throws HotelBookingException 
	{
		
        int uid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid="select seq_user_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			while(rs.next())	
			{
				uid=rs.getInt(1);	
			}
			String insertqry="INSERT into Users values(?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry);
			pst.setInt(1,uid);
			pst.setString(2,user.getPassword());
			pst.setString(3,user.getRole());
			pst.setString(4,user.getUser_name());
			pst.setString(5,user.getMob_no());
			pst.setString(6,user.getPhone());
			pst.setString(7,user.getAddress());
			pst.setString(8,user.getEmail());
			pst.execute();
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return uid;
		
		
		
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
		
		String userPass="",username="";
		int userRole=0;
		try 
		{
			con=DBUtil.getConn();
			String query="SELECT * FROM USERS WHERE user_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,userId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				userPass=rs.getString("password");
				username=rs.getString("user_name");
				if(rs.getString("role").equals("Admin"))
					userRole=1;
			}
			if(userPass.equals(""))
				throw new HotelBookingException("Invalid user ID");
			else
			{
				if(userPass.equals(password))
				{
					if(role==userRole)
						return username;
					else
						throw new HotelBookingException("Password incorrect");
				}
					
					
				else
					throw new HotelBookingException("Password incorrect");
			
		    }
		
		}  
		catch (Exception e)
		{
			e.printStackTrace();
			throw new HotelBookingException("Invalid UserID or Password");  
		}
		
	
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException
	{
		int hid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid1="select seq_hotel_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid1);
			while(rs.next())	
			{
				hid=rs.getInt(1);	
			}
			String insertqry1="INSERT into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry1);
			pst.setInt(1,hid);
			pst.setString(2,hotel.getCity());
			pst.setString(3,hotel.getHotel_name());
			pst.setString(4,hotel.getAddress());
			pst.setString(5,hotel.getDescription());
			pst.setString(6,hotel.getCost());
			pst.setString(7,hotel.getPhno_no1());
			pst.setString(8,hotel.getPhno_no2());
			pst.setString(9,hotel.getRating());
			pst.setString(10,hotel.getEmail());
			pst.setString(11,hotel.getFax());
	        pst.execute();
			
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return hid;
	}

	@Override
	public int modifyHotel(int hotelId,String description)throws HotelBookingException 
	{
		int data=0;
		
		try{		
		    	try 
		    	{
		    		con=DBUtil.getConn();
		    	} 
		    	catch (IOException e) 
		    	{
		    		e.printStackTrace();
		    	}
		    	String updateqry="UPDATE hotel set description=? WHERE hotel_id=?";
		    	pst=con.prepareStatement(updateqry);
		    	pst.setString(1,description);
		    	pst.setInt(2,hotelId);
		    	data=pst.executeUpdate();
			}
			catch (SQLException e) 
        	{
				e.printStackTrace();
				throw new HotelBookingException(e.getMessage());
        	}
		return data;
		
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelBookingException
	{
		int a=0;
		try
		{ 
			con=DBUtil.getConn();
			String deleteqry1="DELETE FROM hotel WHERE hotel_id=?";
			pst=con.prepareStatement(deleteqry1);
			pst.setInt(1,hotel_id);
			a=pst.executeUpdate();
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new HotelBookingException("Not Deleted");
		} 
		finally 
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				//e.printStackTrace();

				throw new HotelBookingException(e.getMessage());
			}
		}
		return a;
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		int data=1;
		try
		{
			con=DBUtil.getConn();
			String query="insert into roomdetails values(?,?,?,?,?,?)";
			pst=con.prepareStatement(query);
			pst.setString(1,room.getHotel_id() );
			//System.out.println(room.getHotel_id());
			pst.setString(2,room.getRoom_id());
			//System.out.println(room.getRoom_id());
			pst.setString(3,room.getRoom_type());
			//System.out.println(room.getRoom_type());
			pst.setFloat(4,room.getCost());
			//System.out.println(room.getCost());
			pst.setString(5,room.getAvailability());
			//System.out.println(room.getAvailability());
			pst.setString(6,room.getPhoto());
			//System.out.println(room.getPhoto());
			
			pst.execute();
			
			
			//Select
			float avg_rate=0;
			String qry1="select * from hotel where hotel_id=?";
			pst=con.prepareStatement(qry1);
			pst.setString(1,room.getHotel_id() );
			rs=pst.executeQuery();
			while(rs.next())
			{
				avg_rate=(Float.parseFloat(rs.getString("avg_rate_pernight"))+room.getCost())/2;
			}
			
			//Update
			String qry2="Update hotel set avg_rate_pernight=? where hotel_id=?";
			pst=con.prepareStatement(qry2);
			pst.setFloat(1, avg_rate);
			pst.setString(2,room.getHotel_id() );
			int aff1=pst.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new HotelBookingException("Unable to add Room details...");  
		}
		
		return data;
		
	}

	/*@Override
	public int modifyRoom(RoomDetails room) throws HotelBookingException
	{
		// TODO Auto-generated method stub
		
		return 0;
	}*/

	@Override
	public int deleteRoom(String hotel_id,String room_id) throws HotelBookingException
	{
		
		int data;
		try{
			con=DBUtil.getConn();
			String query="delete from roomdetails where room_id=? and hotel_id=?";
			pst=con.prepareStatement(query);
			pst.setString(1,room_id);
			pst.setString(2,hotel_id);
			pst.executeQuery();
			data=pst.executeUpdate();
			
		}
		catch(Exception e)
		{
				e.printStackTrace();
			throw new HotelBookingException("Unable to delete Room details...");  
		}
		return data;
		
	}

	@Override
	public String bookRoom(String uid,String daChIn, String daChOut, int ad, int ch, float cost,String hi,String ri)throws HotelBookingException
	{
		// TODO Auto-generated method stub
		String avai="";
		try {
			
			con=DBUtil.getConn();
			String seqid="select seq_book_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			int bid=0;
			while(rs.next())	
			{
				bid=rs.getInt(1);	
			}
			String booking_id=Integer.toString(bid);
			Date	d1 = new SimpleDateFormat("dd/MM/yyyy").parse(daChIn);
			java.sql.Date d11 = new java.sql.Date(d1.getTime());
		 
			Date	d2=new SimpleDateFormat("dd/MM/yyyy").parse(daChOut);
			java.sql.Date d12 = new java.sql.Date(d1.getTime());
		
		String qry="Insert into bookingdetails values(?,?,?,?,?,?,?,?)";
		
			
				con=DBUtil.getConn();
			 
			pst=con.prepareStatement(qry);
		//String bid="1000";
		
			pst.setString(1,booking_id);
		
		
		pst.setString(2,uid);
		pst.setDate(3,d11);
		pst.setDate(4,d12);
		pst.setInt(5,ad);
		pst.setInt(6,ch);
		pst.setDouble(7,cost);
		pst.setString(8, hi);
		int aff=pst.executeUpdate();
		
		if(aff!=0)
		{
			System.out.println("successfully booked!!!");
			String qry1="select availability from roomDetails where room_id=?";
			pst=con.prepareStatement(qry1);
			pst.setString(1, ri);
			rs=pst.executeQuery();
			while(rs.next())
			{
				avai=rs.getString("availability");
			}
			int av=Integer.parseInt(avai);
			av=av-1;
			String av1=(Integer.toString(av));
			
			
			
			String qry2="Update roomdetails set availability=? where room_id=?";
			pst=con.prepareStatement(qry2);
			pst.setString(1, av1);
			pst.setString(2, ri);
			int aff1=pst.executeUpdate();
			return booking_id;
			
		}
		else
		{
			throw new HotelBookingException("Booking Failed");
			
		}
		}
		 catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new HotelBookingException("Booking Failed");
		}
	
	
	}

	@Override
	public ArrayList<BookingDetails> viewBookingStatus(int bookingId)
			throws HotelBookingException 
	{
		ArrayList<BookingDetails> arr=new ArrayList<BookingDetails>();
		String qry="select * from bookingdetails where booking_Id=?";
		String av=Integer.toString(bookingId);
		try
		{
			con=DBUtil.getConn();
			pst=con.prepareStatement(qry);
			pst.setString(1, av);
			rs=pst.executeQuery();
			while(rs.next())
			{
				arr.add(new BookingDetails(av,rs.getString("hotel_id"),rs.getString("user_id"),rs.getDate("booked_from"),rs.getDate("booked_to"),rs.getInt("no_of_adults"),rs.getInt("no_of_children"),rs.getFloat("amount")));
			}
		} 
		catch (IOException|SQLException e) 
		{
			
			e.printStackTrace();
			throw new HotelBookingException("Unable to show boooking status");
		}
		return arr;
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException
	{
		ArrayList<RoomDetails> searchList;
		try
		{
			con=DBUtil.getConn();
			searchList = new ArrayList<RoomDetails>();
			String selectqry="SELECT * FROM RoomDetails WHERE hotel_id = ?";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,hotelId);
			rs=pst.executeQuery();
			
		while(rs.next())
		{
			searchList.add(new RoomDetails(rs.getString("hotel_id"), rs.getString("room_id"),
					rs.getString("room_type"),rs.getFloat("cost"), rs.getString("availability"),
					rs.getString("photo")));
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new HotelBookingException("Does Not Exist");
		}
		return searchList;
		
	}

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		ArrayList<Hotel> hList;
		try
		{
			hList = new ArrayList<Hotel>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from Hotel";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				hList.add(new Hotel(rs.getString("hotel_id"),
						rs.getString("city"),
						rs.getString("hotel_name"),
									rs.getString("address"),
									rs.getString("description"),
									rs.getString("avg_rate_pernight"),
									rs.getString("phone_no1"),
									rs.getString("phone_no2"),
									rs.getString("rating"),
									rs.getString("email"),
									rs.getString("fax")));
			}
		}
		catch(Exception e)
			{
				e.printStackTrace();
				throw new HotelBookingException("Error");
			}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new HotelBookingException(e.getMessage());
			}
		}
		return hList;
		
		
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
	{
		ArrayList<BookingDetails> bookList;
		try
		{
			bookList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from BookingDetails WHERE hotel_id=?";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,hotelId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				bookList.add(new BookingDetails(rs.getString("booking_id"),
												rs.getString("hotel_id"),
												rs.getString("user_id"),
												rs.getDate("booked_from"),
												rs.getDate("booked_to"),
												rs.getInt("no_of_adults"),
												rs.getInt("no_of_children"),
												rs.getFloat("amount")));
			}
		}
		catch(Exception e)
			{
				e.printStackTrace();
				throw new HotelBookingException("Error");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new HotelBookingException(e.getMessage());
			}
		}
		return bookList;
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException
	{
		ArrayList <BookingDetails> guestList;
		try
		{
			guestList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			LocalDate localDate = LocalDate.now();
			//Date date1 = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
			//LocalDate cdate=LocalDate.now();
			java.sql.Date date = java.sql.Date.valueOf(localDate); 
			String selectqry="SELECT * from BookingDetails WHERE hotel_id=? AND ?<=booked_to AND ?>=booked_from";
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,hotelId);
			pst.setDate(2, date);
			pst.setDate(3,date);
			rs=pst.executeQuery();
			while(rs.next())
			{
				guestList.add(new BookingDetails(rs.getString("booking_id"),
						rs.getString("hotel_id"),
						rs.getString("user_id"),
						rs.getDate("booked_from"),
						rs.getDate("booked_to"),
						rs.getInt("no_of_adults"),
						rs.getInt("no_of_children"),
						rs.getFloat("amount")));
			}
		}
		
	     catch(Exception e)
	    {
		  e.printStackTrace();
		  throw new HotelBookingException("Error");
     	}
         finally
        {
 	      try
	    {
		  pst.close();
		  rs.close();
		  con.close();
	    }
	     catch(SQLException e)
	    {
		  e.printStackTrace();
		  throw new HotelBookingException(e.getMessage());
	    }
        }
        return guestList;	
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException 
	{
		ArrayList<BookingDetails> bookList;
		try
		{
			bookList = new ArrayList<BookingDetails>();
			con=DBUtil.getConn();
			//Date	d1 = new SimpleDateFormat("dd/MM/yyyy").parse(date);
			java.sql.Date d11 = new java.sql.Date(date.getTime());
			//java.sql.Date date1 = java.sql.Date.valueOf(date);
			String selectqry="SELECT * from BookingDetails WHERE booked_from=?";
			pst=con.prepareStatement(selectqry);
			pst.setDate(1,d11);
			rs=pst.executeQuery();
			while(rs.next())
			{
				bookList.add(new BookingDetails(rs.getString("booking_id"),
									rs.getString("hotel_id"),
									rs.getString("user_id"),
									rs.getDate("booked_from"),
									rs.getDate("booked_to"),
									rs.getInt("no_of_adults"),
									rs.getInt("no_of_children"),
									rs.getFloat("amount")));
			}
		}
		catch(Exception e)
			{
				e.printStackTrace();
				throw new HotelBookingException("Error");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new HotelBookingException(e.getMessage());
			}
		}
		return bookList;	
	
	}

	@Override
	public Boolean checkAv(String hi, String tp) throws HotelBookingException 
	{
		String av="";
		String qry="select * from roomDetails where hotel_id=? and room_type=? ";
		try {
		
				con=DBUtil.getConn();
			
			pst=con.prepareStatement(qry);
		
		
		
		pst.setString(1,hi);
		pst.setString(2, tp);
		rs=pst.executeQuery();
		while(rs.next())
		{
			av=rs.getString("availability");
		}
		
		
		} 
		catch (IOException|SQLException e) 
		{
			
			e.printStackTrace();
			throw new HotelBookingException("Not Available");
		}
		if(av.equals("0"))
		{
			return false;
		}
		else
		{
			return true;
			
		}
		
	}

	@Override
	public float clacCost(int day,String rid)
	{	String co="0";
		float cost=0;
		String qry="Select per_night_rate from roomdetails where room_id=? ";
		try {
			con=DBUtil.getConn();
		
			
		
		pst=con.prepareStatement(qry);
		pst.setString(1, rid);
		rs=pst.executeQuery();
		while(rs.next())
		{
			co=rs.getString("per_night_rate");
		}
		}
		catch (IOException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int co1=Integer.parseInt(co);
		cost=(float)day*co1;
		return cost;
		
	}

	@Override
	public ArrayList<RoomDetails> displayRooms(String hi)
			throws HotelBookingException {
		ArrayList<RoomDetails> arrl=new ArrayList<RoomDetails>();
		String qry="select * from roomdetails where hotel_id=?";
		
			try {
				con=DBUtil.getConn();
			
			pst=con.prepareStatement(qry);
			pst.setString(1, hi);
			rs=pst.executeQuery();
			while(rs.next())
			{
				arrl.add(new RoomDetails(hi, rs.getString("room_id"), rs.getString("room_type"), rs.getFloat("per_night_rate"), rs.getString("availability"), null));
			}
			
		} catch (IOException|SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return arrl;
	}

	@Override
	public ArrayList<Hotel> displayHotelByCity(String city)
			throws HotelBookingException 
	{
		ArrayList<Hotel> hList;
		try
		{
			hList = new ArrayList<Hotel>();
			con=DBUtil.getConn();
			String selectqry="SELECT * from Hotel where city=?";
			pst=con.prepareStatement(selectqry);
			pst.setString(1, city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hList.add(new Hotel(rs.getString("hotel_id"),
						rs.getString("city"),
						rs.getString("hotel_name"),
									rs.getString("address"),
									rs.getString("description"),
									rs.getString("avg_rate_pernight"),
									rs.getString("phone_no1"),
									rs.getString("phone_no2"),
									rs.getString("rating"),
									rs.getString("email"),
									rs.getString("fax")));
			}
		}
		catch(Exception e)
			{
				e.printStackTrace();
				throw new HotelBookingException("Error");
			}
		finally
		{
			try
			{
				pst.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new HotelBookingException(e.getMessage());
			}
		}
		return hList;
		
	}

	
	

}

package com.cg.hms.dao;

import java.util.ArrayList;
import java.util.Date;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public interface HotelBookingDao 
{

	public int register(User user)throws HotelBookingException;
	public String login(int role,int user_id,String password)throws HotelBookingException;
	public int addHotel(Hotel hotel)throws HotelBookingException;
	public int modifyHotel(int hotelId,String description)throws HotelBookingException;
	public int deleteHotel(int hotel_id)throws HotelBookingException;
	public int addRoom(RoomDetails room)throws HotelBookingException;
	//public int modifyRoom(RoomDetails room)throws HotelBookingException;
	public int deleteRoom(String hotel_id,String room_id)throws HotelBookingException;
	public String bookRoom(BookingDetails bookingDetails )throws HotelBookingException;
	public BookingDetails viewBookingStatus(int bookingId)throws HotelBookingException;
	public ArrayList<RoomDetails> searchRoom(int hotelId)throws HotelBookingException;
	public ArrayList<Hotel> displayHotels()throws HotelBookingException;
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)throws HotelBookingException;
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)throws HotelBookingException;
	public ArrayList<BookingDetails> viewBookingByDate(Date date)throws HotelBookingException;
}